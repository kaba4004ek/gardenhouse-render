(() => {
  const button = document.querySelector('.menu-button');
  const nav = document.querySelector('.nav');
  if (button && nav) {
    button.addEventListener('click', () => {
      const open = nav.classList.toggle('nav-open');
      button.setAttribute('aria-expanded', String(open));
      button.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    });
    nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
      nav.classList.remove('nav-open');
      button.setAttribute('aria-expanded', 'false');
    }));
  }
})();
