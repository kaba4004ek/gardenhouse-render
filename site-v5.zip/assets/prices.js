(() => {
  const range = document.querySelector('#area-range');
  const areaOutput = document.querySelector('#area-output');
  const priceOutput = document.querySelector('#price-output');
  if (!range || !areaOutput || !priceOutput) return;

  const formatter = new Intl.NumberFormat('ru-RU');
  const update = () => {
    const area = Number(range.value);
    areaOutput.textContent = `${area} м²`;
    priceOutput.textContent = `от ${formatter.format(area * 70000)} ₽`;
  };

  range.addEventListener('input', update);
  update();
})();
